import React from "react";
import "./myStyle.css";
import Skills from "./Skills";
import AcademicQualification from "./AcademicQualification";
import Projects from "./Projects";
import Certificates from "./Certificates";
import Internship from "./Internship";
import PersonalDetail from "./PersonalDetail";
const App = () => {
  return (
      <div className="container mt-5 ">
        


          <div className="d-flex  justify-content-end">
             
              <h3 className="text-center text-primary ">SAMBHAVI RASSEWATT</h3>
              </div>
                         
          <AcademicQualification
              inf1="Panjab University"
              inf2="Post Graduate Government College For Girls-42"
              inf3="Pinewood School, Saharanpur junction"
              inf4="Asha Modern International School, Saharanpur junction "
          />
          <Internship
              int1="REDLIZARD (June 4, 2018 - July 9, 2018)"
              int2="smartData Enterprises (Jan 20, 2020 - March 18, 2020)"
              int3="Training in Core Java (6 weeks) at OOPs Info Solutions"
          />
          <Skills
            database="MySQL"
            languages="C, C++, Java, SQL"
            webDevelopment="HTML, CSS, JavaScript, React JS, Bootstrap, Angular"
          />

          <Projects
              prj1="Domain Specific Knowledge Analyzer"
              prj2="Movie Ticket Booking System"
              prj3="Teacher Performance Evaluator"
          />
          <Certificates
              cert1="Hackathon"
              cert2="IT Fest"
          />
           <PersonalDetail/>
      
    </div>
  );
};

export default App;

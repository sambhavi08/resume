import React from "react";

function Internship({ int1, int2, int3 }) {
    return (
        <div className='mt-5'>
            <h4 className='textmiddle text-primary'>INTERNSHIP AND TRAINING</h4>
            <h5>{int1}</h5>
            <div className="mb-2"><span className="font-weight-bold"> Key Skills: </span>UI DEVELOPMENT USER EXPERIENCE</div>
            <h5>{int2}</h5>
            <div className="mb-2"><span className="font-weight-bold"> Key Skills:</span> HTML CSS BOOTSTRAP JAVASCRIPT ANGULAR REACT</div>
            <h5>{int3}</h5>
        </div>
    );
}

export default Internship;

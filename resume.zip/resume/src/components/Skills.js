import React from "react";
import "./myStyle.css";
const Skills = ({ languages, tools, database, webDevelopment }) => {
    return (
        <div className='mt-5'>
            <h3 className='textmiddle text-primary'><span className='m-5'>SKILLS</span></h3>
          <div className=" mt-3">
              <div className="container">
                  <div className="row">
                       <h5 className="col-4 p-0 ">Languages:</h5>
                       <div className="col-8 ">{languages}</div>
                  </div>
              </div>
              <div className="container">
                  <div className="row">
                      <h5 className="col-4 p-0" >Web Development:</h5>
                      <div className="col-8 ">{webDevelopment}</div>
                  </div>
              </div>
              <div className="container">
                  <div className="row">
                      <h5 className="col-4 p-0" >Database:</h5>
                      <div className="col-8 "> {database}</div>
                  </div>
              </div>
             
             
    </div>
    </div>
  );
};

export default Skills;

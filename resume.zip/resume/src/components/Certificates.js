import React from "react";

const Certificates = ({ cert1, cert2 }) => {
  return (
      <div className='mt-5'>
          <h4 className='textmiddle text-primary'><span className='m-5'>CERTIFICATES</span></h4>
         <div>
              <h5>{cert1}</h5>
              <div className="mb-2">Participated in Smart India Hackathon2018 (Grand Finale) competition organized by government of India</div>
         </div>
          <div>
              <h5> {cert2}</h5>
              <div className="mb-2">Second Position in Debate</div>
          </div>
       
   
    </div>
  );
};

export default Certificates;

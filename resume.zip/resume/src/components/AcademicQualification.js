import React from "react";

function AcademicQualification({ inf1,inf2,inf3,inf4 }) {
  return (
      <div className='mt-5'>
          <h4 className='textmiddle text-primary'>ACADEMIC QUALIFICATION</h4>
          <h5>{inf1}</h5>
          <div className="mb-2">M.C.A. - Computer Applications | Aggregate : 71.12 / 100.00</div>
          <h5>{inf2}</h5>
          <div className="mb-2">B.Sc. - Information Technology | Aggregate: 65.00 / 100.00</div>
          <h5>{inf3}</h5>
          <div className="mb-2">12th   |   CBSE   |   Percentage: 77.80 / 100.00</div>
          <h5>{inf4}</h5>
          <div className="mb-2">10th | CBSE | CGPA: 10.00 / 10.00</div>
    </div>
  );
}

export default AcademicQualification;

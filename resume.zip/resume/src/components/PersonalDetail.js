import React from "react";

function PersonalDetail() {
    return (
        <div className="mt-5">
        <h4 className='textmiddle text-primary'>INTERNSHIP AND TRAINING</h4>
        <div className="container">
            <div className="row">
            <div className="col-8">
                <div>
                    <span className="font-weight-bold"> Gender:</span> Female
                </div>
                <div>
                    <span className="font-weight-bold"> Marital Status:</span> Unmarried
                </div>
                <div>
                    <span className="font-weight-bold">Emails:</span> rassewattsavi@gmail.com
                </div>
                <div>
                    <span className="font-weight-bold"> Phone Numbers:</span> +91-7696933406, +91-8077952918
                </div>

            </div>
            <div className="col-4">
               <div> <span className="font-weight-bold">Date of Birth: </span>Feb. 8, 1996</div>
                 <div><span className="font-weight-bold">Permanent Address:</span> 3/1943, A, Beri Bagh, Saharanpur, Uttar Pradesh - 247001</div>

            </div>
                </div>
            </div>
            </div>
    );
}

export default PersonalDetail;

import React from "react";
import "./myStyle.css";
const Projects = ({ prj1, prj2, prj3, prj4 }) => {
  return (
    <div className='mt-5'>
          <h4 className='textmiddle text-primary'><span className='m-5'>PROJECTS</span></h4>
          <div className='mt-3'>
              <h5>Domain Specific Knowledge Analyzer</h5>
              <h6> Key Skills:   MySQL	C++</h6>
              <div>
                  A desktop application that puts forward questions in the form of MCQ's and hence analyzes the user's domain specific knowledge.
                  The software has practical life application wherein it can be used to test and rank various job candidates based on their performance
                  or it can be used as a general fun game by tweaking the functionality appropriately.
              </div>
          </div>
          <div className='mt-3'>
            <h5>Movie Ticket Booking System</h5>
            <h6>Key Skills:   C#	HTML	CSS</h6>
              <div>A web application for movie booking that displays the latest show, their timing, performance stars and allows you to select your movie 
              online beforehand. It also allows you to select your seat for the greater and comfortable experience of the movie.
               </div>
          </div>
          <div className='mt-3'>
              <h5>Teacher Performance Evaluator</h5>
              <h6>Key Skills:   Java	MySQL</h6>
              <div>
                  This application allows student to give their feedback for their subject teachers at the end of semester and one can also review the visual interpretation of 
                  the teacher performances in different aspects in the form of a graph and also their overall performance in the form of grade.
              </div>
          </div>

    </div>
  );
};

export default Projects;
